import React, { useCallback, useState } from 'react';
import { StyleSheet, View, ScrollView, RefreshControl } from 'react-native';
import { ActivityIndicator, Card, Icon, Text, useTheme } from 'react-native-paper';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import {
  fetchAthleteSessionHistory,
  SessionMetricRecord,
} from '@/lib/sessionService';

// ─── Helpers ─────────────────────────────────────────────────

function formatDuration(totalSeconds: number): string {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m`;
  if (m > 0) return `${m}m ${String(s).padStart(2, '0')}s`;
  return `${s}s`;
}

function formatDate(iso: string): { day: string; month: string; time: string } {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return { day: '--', month: '', time: '' };
  return {
    day: String(d.getDate()),
    month: d.toLocaleDateString(undefined, { month: 'short' }).toUpperCase(),
    time: d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }),
  };
}

function formatDistance(meters: number): { value: string; unit: string } {
  return meters >= 1000
    ? { value: (meters / 1000).toFixed(2), unit: 'km' }
    : { value: String(Math.round(meters)), unit: 'm' };
}

// ─── Weekly Load Trend (no data yet) ─────────────────────────

function WeeklyLoadEmpty() {
  const theme = useTheme();
  return (
    <View style={emptyStyles.container}>
      <View style={[emptyStyles.iconWrap, { backgroundColor: theme.colors.primaryContainer }]}>
        <Icon source="chart-line-variant" size={26} color={theme.colors.primary} />
      </View>
      <Text variant="bodyMedium" style={{ color: theme.colors.onSurface, fontWeight: '600' }}>
        No data yet
      </Text>
      <Text
        variant="bodySmall"
        style={{ color: theme.colors.onSurfaceVariant, textAlign: 'center' }}
      >
        Your weekly load trend will appear here.
      </Text>
    </View>
  );
}

const emptyStyles = StyleSheet.create({
  container: { alignItems: 'center', paddingVertical: 20, gap: 6 },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
});

// ─── Stat ────────────────────────────────────────────────────

function Stat({
  icon,
  label,
  value,
  unit,
}: {
  icon: string;
  label: string;
  value: string;
  unit?: string;
}) {
  const theme = useTheme();
  return (
    <View style={sessionStyles.stat}>
      <View style={sessionStyles.statLabelRow}>
        <Icon source={icon} size={12} color={theme.colors.onSurfaceVariant} />
        <Text
          style={{
            color: theme.colors.onSurfaceVariant,
            fontSize: 10,
            fontWeight: '600',
            letterSpacing: 0.6,
          }}
        >
          {label}
        </Text>
      </View>
      <View style={sessionStyles.statValueRow}>
        <Text variant="titleMedium" style={{ color: theme.colors.onSurface, fontWeight: '700' }}>
          {value}
        </Text>
        {unit ? (
          <Text
            variant="bodySmall"
            style={{ color: theme.colors.onSurfaceVariant, marginLeft: 3 }}
          >
            {unit}
          </Text>
        ) : null}
      </View>
    </View>
  );
}

// ─── Session Card ────────────────────────────────────────────

function SessionCard({ record }: { record: SessionMetricRecord }) {
  const theme = useTheme();
  const date = formatDate(record.completedAt);
  const distance = formatDistance(record.meters);

  return (
    <Card
      mode="elevated"
      style={[sessionStyles.card, { backgroundColor: theme.colors.elevation.level1 }]}
    >
      <Card.Content style={sessionStyles.content}>
        <View style={sessionStyles.headerRow}>
          <View style={[sessionStyles.dateBadge, { backgroundColor: theme.colors.primaryContainer }]}>
            <Text style={{ color: theme.colors.primary, fontSize: 18, fontWeight: '800' }}>
              {date.day}
            </Text>
            <Text
              style={{
                color: theme.colors.primary,
                fontSize: 10,
                fontWeight: '700',
                letterSpacing: 0.8,
              }}
            >
              {date.month}
            </Text>
          </View>

          <View style={sessionStyles.titleGroup}>
            <Text
              variant="titleSmall"
              numberOfLines={2}
              style={{ color: theme.colors.onSurface, fontWeight: '700' }}
            >
              {record.sessionTitle}
            </Text>
            <Text variant="bodySmall" style={{ color: theme.colors.onSurfaceVariant, marginTop: 2 }}>
              {date.time} · {formatDuration(record.totalSeconds)}
              {record.watchName ? ` · ${record.watchName}` : ''}
            </Text>
          </View>

          <View style={sessionStyles.loadBlock}>
            <Text
              style={{ color: theme.colors.primary, fontSize: 24, fontWeight: '800', lineHeight: 28 }}
            >
              {Math.round(record.playerLoadAU)}
            </Text>
            <Text
              style={{
                color: theme.colors.onSurfaceVariant,
                fontSize: 10,
                fontWeight: '600',
                letterSpacing: 0.6,
              }}
            >
              LOAD AU
            </Text>
          </View>
        </View>

        <View style={[sessionStyles.divider, { backgroundColor: theme.colors.outlineVariant }]} />

        <View style={sessionStyles.statsRow}>
          <Stat icon="shoe-print" label="STEPS" value={record.steps.toLocaleString()} />
          <Stat icon="map-marker-distance" label="DISTANCE" value={distance.value} unit={distance.unit} />
          <Stat icon="arrow-up-bold" label="JUMPS" value={String(record.jumps)} />
          <Stat
            icon="heart-pulse"
            label="AVG HR"
            value={record.avgHeartRate > 0 ? String(record.avgHeartRate) : '--'}
            unit={record.avgHeartRate > 0 ? 'bpm' : undefined}
          />
        </View>
      </Card.Content>
    </Card>
  );
}

const sessionStyles = StyleSheet.create({
  card: { borderRadius: 20 },
  content: { gap: 12 },
  headerRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  dateBadge: {
    width: 48,
    height: 52,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleGroup: { flex: 1 },
  loadBlock: { alignItems: 'flex-end' },
  divider: { height: StyleSheet.hairlineWidth },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between' },
  stat: { gap: 2, flex: 1 },
  statLabelRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statValueRow: { flexDirection: 'row', alignItems: 'baseline' },
});

// ─── Main Screen ─────────────────────────────────────────────

export default function HistoryScreen() {
  const theme = useTheme();
  const [records, setRecords] = useState<SessionMetricRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const { data, error: err } = await fetchAthleteSessionHistory();
    setRecords(data);
    setError(err ?? null);
    setLoading(false);
    setRefreshing(false);
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  return (
    <SafeAreaView style={[styles.safeArea, { backgroundColor: theme.colors.background }]}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={() => {
              setRefreshing(true);
              load();
            }}
          />
        }
      >
        <View>
          <Text
            variant="headlineLarge"
            style={[styles.pageTitle, { color: theme.colors.onBackground }]}
          >
            Activity history
          </Text>
          <Text variant="bodyMedium" style={{ color: theme.colors.onSurfaceVariant }}>
            {records.length} completed session{records.length === 1 ? '' : 's'}
          </Text>
        </View>

        <Card
          mode="elevated"
          style={[styles.trendCard, { backgroundColor: theme.colors.elevation.level1 }]}
        >
          <Card.Content>
            <Text
              variant="titleSmall"
              style={{ color: theme.colors.onSurface, fontWeight: '600' }}
            >
              Weekly load trend
            </Text>
            <WeeklyLoadEmpty />
          </Card.Content>
        </Card>

        {loading ? (
          <ActivityIndicator style={{ marginTop: 24 }} />
        ) : error ? (
          <Text style={{ color: theme.colors.error, textAlign: 'center' }}>
            Couldn't load history: {error}
          </Text>
        ) : records.length === 0 ? (
          <View style={styles.emptyList}>
            <Icon source="history" size={40} color={theme.colors.onSurfaceVariant} />
            <Text variant="titleSmall" style={{ color: theme.colors.onSurface, fontWeight: '600' }}>
              No sessions yet
            </Text>
            <Text
              variant="bodySmall"
              style={{ color: theme.colors.onSurfaceVariant, textAlign: 'center' }}
            >
              Completed tracking sessions will show up here.
            </Text>
          </View>
        ) : (
          records.map((r) => <SessionCard key={r.id} record={r} />)
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// ─── Styles ──────────────────────────────────────────────────

const styles = StyleSheet.create({
  safeArea: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 32, gap: 16 },
  pageTitle: { fontWeight: '700' },
  trendCard: { borderRadius: 20 },
  emptyList: { alignItems: 'center', gap: 6, paddingVertical: 32 },
});
